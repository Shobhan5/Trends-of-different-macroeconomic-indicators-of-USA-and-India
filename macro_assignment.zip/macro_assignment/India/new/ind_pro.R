---
title: "India_Project"
author: "shobhan sarkar"
date: "`r Sys.Date()`"
output: html_document
---

```{try r}
# Assuming you have your investment data in a CSV file named "investment_data.csv"
# Replace "investment_data.csv" with the actual file path

# Read the CSV file
investment_data <- read.csv(r"C:\Users\Shobhan Sarkar\OneDrive\Desktop\macro_assignment\India\new\India_Investment_as_a_fraction_of_GDP.csv")

# Plot the trend line
plot(investment_data$Time, investment_data$Inv, type = "l", col = "blue", xlab = "Year", ylab = "Investment", main = "Yearly Investment Trend in India")

# Add a trend line
abline(lm(Inv ~ Time, data = investment_data), col = "red")

# Show the plot#timestamp() Show the plot

```

